import { useState, useEffect } from 'react';

const useCurrencyinfo = (currency) => {
    const [data, setData] = useState({});

    useEffect(() => {
        if (!currency) return; // Ensure currency is valid

        fetch(`https://latest.currency-api.pages.dev/v1/currencies/${currency}.json`)
            .then((res) => {
                if (!res.ok) throw new Error("Network response was not ok");
                return res.json();
            })
            .then((res) => {
                console.log(res);
                setData(res[currency] || {}); // Ensure data is properly set if not then set empty object
            })
            .catch((error) => {
                console.error("Error fetching data:", error);
                setData({}); // Reset data on error
            });
    }, [currency]);

    return data;
};

export default useCurrencyinfo;